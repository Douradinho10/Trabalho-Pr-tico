## Packages
date-fns | Date formatting for timestamps
framer-motion | Smooth animations for list entry and sequence updates

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  mono: ["var(--font-mono)"],
}
